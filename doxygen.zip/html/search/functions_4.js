var searchData=
[
  ['trigger_5fsensor',['trigger_sensor',['../main_8c.html#a875c90a3098ecb97e31d8c1badf5912a',1,'main.c']]]
];
