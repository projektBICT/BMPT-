var searchData=
[
  ['nov',['Nov',['../main_8c.html#a542f9ca4fac316b6d156f3ac7b16399a',1,'main.c']]]
];
