var searchData=
[
  ['setup',['setup',['../main_8c.html#a7dfd9b79bc5a37d7df40207afbc5431f',1,'main.c']]]
];
