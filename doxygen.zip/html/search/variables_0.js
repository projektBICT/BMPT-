var searchData=
[
  ['timer',['timer',['../main_8c.html#aea00c2c1dec6e8f58532f25c65210d9e',1,'main.c']]],
  ['timer_5fstarted',['timer_started',['../main_8c.html#affd943ea98328b0b38a0e9ef44500b73',1,'main.c']]]
];
