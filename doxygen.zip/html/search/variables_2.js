var searchData=
[
  ['technology',['Technology',['../main_8c.html#ada1b6ff339c2004c9ca265ffd9970895',1,'main.c']]]
];
